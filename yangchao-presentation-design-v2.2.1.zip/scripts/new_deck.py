#!/usr/bin/env python3
"""Create an empty presentation shell, never copy historical example slides."""
import argparse
from pathlib import Path
import shutil
import sys

def create(destination):
    skill = Path(__file__).resolve().parents[1]
    destination = Path(destination).expanduser().absolute()
    if destination.exists():
        raise FileExistsError("目标已存在；请选择新目录，不覆盖已有作品。")
    if skill == destination or skill in destination.parents:
        raise ValueError("作品不能写入已安装技能目录。")
    shutil.copytree(skill / "templates" / "starter", destination)
    (destination / "slides").mkdir()
    (destination / "assets").mkdir()
    for name in ("CREDITS.md", "LICENSE-HUASHU.txt"):
        shutil.copy2(skill / name, destination / name)
    return destination

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination")
    args = parser.parse_args()
    try:
        result = create(args.destination)
    except (OSError, ValueError) as exc:
        print(f"创建失败：{exc}", file=sys.stderr)
        return 2
    print(f"已创建空演示底座：{result}")
    print("请根据本次内容编写 slides 与 DECK_MANIFEST；未复制案例页。")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
