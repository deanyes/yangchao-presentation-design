#!/usr/bin/env python3
"""Static checks: dependencies, manifest, duplicate IDs and historical sample leakage."""
import argparse
from collections import Counter
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit

class Document(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs, self.ids, self.private = [], [], []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        line = self.getpos()[0]
        if attrs.get("id"): self.ids.append(attrs["id"])
        for key in ("src", "poster"):
            if attrs.get(key): self.refs.append((attrs[key], line, "asset"))
        if attrs.get("href"): self.refs.append((attrs["href"], line, "asset" if tag == "link" else "link"))
        if attrs.get("srcset") and not attrs["srcset"].startswith("data:"):
            for entry in attrs["srcset"].split(","):
                parts = entry.strip().split()
                if parts: self.refs.append((parts[0], line, "asset"))
        markers = attrs.get("class", "") + " " + attrs.get("id", "")
        if any(x in markers for x in ("speaker-notes", "private-notes", "presenter-notes")):
            self.private.append(line)

def scan(target, allow_examples=False):
    target = Path(target).resolve()
    root = target if target.is_dir() else target.parent
    errors, warnings = [], []
    if not target.exists():
        return {"errors": ["目标不存在"], "warnings": [], "files": 0}
    paths = sorted(target.rglob("*")) if target.is_dir() else [target]
    paths = [p for p in paths if p.is_file() and not any(x.startswith(".") or x == "_work" for x in p.relative_to(root).parts)]
    example_root = Path(__file__).resolve().parents[1] / "examples/original-talk/assets"
    example_hashes = {hashlib.sha256(p.read_bytes()).hexdigest(): p.name for p in example_root.glob("*") if p.is_file()}
    read_count = 0
    for path in paths:
        label = str(path.relative_to(root))
        if not allow_examples:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest in example_hashes:
                errors.append(f"{label}: 沿用了案例库样张 {example_hashes[digest]}；改名不能改变内容，不能作为本次正式素材。")
        if path.suffix.lower() not in (".html", ".css", ".svg"):
            continue
        read_count += 1
        text = path.read_text(encoding="utf-8")
        doc = Document()
        if path.suffix.lower() in (".html", ".svg"): doc.feed(text)
        for match in re.finditer(r'''url\(\s*(?:"([^"]*)"|'([^']*)'|([^\s)]*))\s*\)''', text):
            ref = next(v for v in match.groups() if v is not None)
            doc.refs.append((ref, text[:match.start()].count("\n") + 1, "asset"))
        for value, line, kind in doc.refs:
            url = urlsplit(value)
            where = f"{label}:{line}"
            if not value or value == "about:blank" or value.startswith("#") or url.scheme in ("data", "blob", "mailto", "tel"):
                continue
            if url.scheme in ("https", "http") or value.startswith("//"):
                if kind == "asset": warnings.append(f"{where}: 联网资源 {value}，需验证离线/加载失败方案。")
                continue
            if url.scheme == "file" or value.startswith("/") or re.match(r"^[A-Za-z]:[\\/]", value):
                errors.append(f"{where}: 不可移植的绝对引用 {value}")
                continue
            local = (path.parent / unquote(url.path)).resolve()
            if not local.is_relative_to(root):
                errors.append(f"{where}: 引用位于演示包之外 {value}")
            elif not local.exists():
                errors.append(f"{where}: 缺少本地文件 {value}")
        for key, count in Counter(doc.ids).items():
            if count > 1: errors.append(f"{label}: 重复 ID {key}")
        for line in doc.private: warnings.append(f"{label}:{line}: 观众页面疑似包含讲者私用备注。")
        if "DECK_MANIFEST" in text and path.suffix == ".html":
            match = re.search(r"window\.DECK_MANIFEST\s*=\s*\[([\s\S]*?)\]\s*;", text)
            if not match:
                warnings.append(f"{label}: 未识别静态 manifest，请人工检查全部 file/steps。")
            else:
                body = match[1].strip()
                objects = re.findall(r"\{([^{}]*)\}", body)
                if not body: errors.append(f"{label}: manifest 为空，仍是未制作的技术外壳。")
                files = []
                for item in objects:
                    file_match = re.search(r'''["']?file["']?\s*:\s*(["'])(.*?)\1''', item)
                    step_match = re.search(r'''["']?steps["']?\s*:\s*(-?\d+)\s*(?:,|$)''', item)
                    if not file_match or not step_match:
                        warnings.append(f"{label}: 清单项无法完整解析 file/steps，需人工检查。")
                        continue
                    file, steps = file_match[2], int(step_match[1])
                    files.append(file)
                    local = (path.parent / file).resolve()
                    if not local.is_relative_to(root): errors.append(f"{label}: 页面引用越出包目录 {file}")
                    elif not local.is_file(): errors.append(f"{label}: manifest 页面不存在 {file}")
                    if steps < 0: errors.append(f"{label}: 步骤不能为负 {file}")
                if body and not objects: warnings.append(f"{label}: 动态清单需人工核验，不执行其中代码。")
                if len(files) != len(set(files)): warnings.append(f"{label}: 多个条目指向同一页面，确认不是未替换副本。")
    return {"files": read_count, "errors": errors, "warnings": warnings,
            "limits": "静态检查不理解观点、图片语义、布局、点击遮挡与动画质量。必须另做逐页浏览器与内容核对。"}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("target")
    p.add_argument("--json", action="store_true")
    p.add_argument("--allow-examples", action="store_true", help="仅检查案例库本身时用，不用于正式作品")
    args = p.parse_args()
    try: result = scan(args.target, args.allow_examples)
    except (OSError, ValueError, UnicodeError) as exc:
        result = {"errors": [str(exc)], "warnings": [], "files": 0}
    if args.json: print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"检查 {result['files']} 个 HTML/CSS/SVG：{len(result['errors'])} 个错误，{len(result['warnings'])} 个提醒")
        for message in result["errors"] + result["warnings"]: print("- " + message)
        print(result.get("limits", "检查未完成"))
    return 2 if result["errors"] else 0

if __name__ == "__main__":
    raise SystemExit(main())
