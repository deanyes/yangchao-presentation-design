(function () {
  window.makeDeckStepper = function makeDeckStepper(options) {
    const root = options.root || document.querySelector('.slide') || document.body;
    const max = Number(options.max || 0);
    let step = Math.max(0, Math.min(max, Number(options.initial || 0)));
    const notifyParent = () => {
      if (window.parent !== window) window.parent.postMessage({ type: 'deck-step-state', step, max }, '*');
    };
    const render = () => {
      root.dataset.step = String(step);
      for (let i = 0; i <= max; i += 1) root.classList.toggle('step-' + i, i === step);
      root.querySelectorAll('[data-show-steps]').forEach(element => {
        const active = element.dataset.showSteps.split(/[ ,]+/).map(Number).includes(step);
        element.setAttribute('aria-hidden', String(!active));
        element.inert = !active;
      });
      if (typeof options.render === 'function') options.render(step);
      notifyParent();
    };
    window.__deckStep = function (direction) {
      const next = Math.max(0, Math.min(max, step + (direction > 0 ? 1 : -1)));
      if (next === step) return false;
      step = next;
      render();
      return true;
    };
    if (options.trigger) {
      const trigger = typeof options.trigger === 'string' ? document.querySelector(options.trigger) : options.trigger;
      if (trigger) trigger.addEventListener('click', () => {
        if (step < max) window.__deckStep(1);
        else { step = 0; render(); }
      });
    }
    window.addEventListener('message', event => {
      if (event.source !== parent || !event.data || event.data.type !== 'deck-set-step') return;
      step = Math.max(0, Math.min(max, Number(event.data.step) || 0));
      render();
    });
    render();
    window.__ready = true;
    return { getStep: () => step };
  };
  if (!window.__ready) window.__ready = true;
}());
