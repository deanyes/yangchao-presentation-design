/* 杨超·演示设计：无主题依赖的连续动画编排。页面自行提供可读终态。 */
(function (global) {
  "use strict";
  global.createPresentationMotion = function (root) {
    root = root || document;
    const media = global.matchMedia ? global.matchMedia("(prefers-reduced-motion: reduce)") : null;
    let animations = [];
    let restorers = [];
    let disposed = false;
    function elements(target) {
      if (typeof target === "string") return Array.from(root.querySelectorAll(target));
      if (target && target.nodeType === 1) return [target];
      return target ? Array.from(target) : [];
    }
    function restore() {
      animations.forEach(a => a.cancel());
      animations = [];
      restorers.reverse().forEach(fn => fn());
      restorers = [];
    }
    function endStyle(element, frames) {
      const final = frames[frames.length - 1];
      Object.keys(final).filter(k => !["offset", "easing", "composite"].includes(k)).forEach(key => {
        const old = element.style[key];
        restorers.push(() => { element.style[key] = old; });
        element.style[key] = final[key];
      });
    }
    function finish() {
      animations.forEach(a => { try { a.finish(); } catch (_) {} });
    }
    function play(cues, options) {
      if (disposed) throw new Error("Motion controller is disposed.");
      if (!Array.isArray(cues)) throw new TypeError("Motion cues must be an array.");
      const jobs = [];
      cues.forEach(cue => {
        elements(cue.target).forEach((element, index) => {
          const frames = typeof cue.keyframes === "function" ? cue.keyframes(element, index) : cue.keyframes;
          if (!Array.isArray(frames) || frames.length < 2) throw new TypeError("Use at least two keyframes per target.");
          const duration = Number(cue.duration == null ? 800 : cue.duration);
          const delay = Number(cue.at == null ? 0 : cue.at) + index * Number(cue.stagger == null ? 0 : cue.stagger);
          if (!Number.isFinite(duration) || !Number.isFinite(delay) || duration < 0 || delay < 0) throw new RangeError("Invalid motion timing.");
          jobs.push({ element, frames, duration, delay, easing: cue.easing || "cubic-bezier(.16,1,.3,1)" });
        });
      });
      restore();
      const reduced = options && options.reduced != null ? Boolean(options.reduced) : Boolean(media && media.matches);
      jobs.forEach(job => {
        if (reduced || !job.element.animate) endStyle(job.element, job.frames);
        else animations.push(job.element.animate(job.frames, {duration:job.duration, delay:job.delay, easing:job.easing, fill:"both", iterations:1}));
      });
      return Promise.all(animations.map(a => a.finished.catch(() => undefined)));
    }
    function trace(target, timing) {
      return Object.assign({}, timing || {}, {target, keyframes(element) {
        if (typeof element.getTotalLength !== "function") throw new TypeError("trace requires an SVG geometry element.");
        const length = element.getTotalLength();
        return [{strokeDasharray:String(length),strokeDashoffset:String(length)},
                {strokeDasharray:String(length),strokeDashoffset:"0"}];
      }});
    }
    const onPreference = e => { if (e.matches) finish(); };
    if (media && media.addEventListener) media.addEventListener("change", onPreference);
    global.addEventListener("pagehide", restore);
    function dispose() {
      restore(); disposed = true;
      if (media && media.removeEventListener) media.removeEventListener("change", onPreference);
      global.removeEventListener("pagehide", restore);
    }
    return {play, trace, finish, cancel:restore, dispose};
  };
}(window));
