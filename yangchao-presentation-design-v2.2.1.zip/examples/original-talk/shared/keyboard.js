/* 同款母版适配：保留证据阅读焦点，将导航键传给外壳。 */
(function(){
 if(parent===window)return;
 addEventListener('keydown',function(e){
  if(e.target.closest('input,textarea,select,[contenteditable="true"]') && e.key!=='Escape')return;
  if(e.target.closest('[data-deck-interactive]') && !['Escape','r','R'].includes(e.key))return;
  if(['ArrowRight','ArrowLeft','PageUp','PageDown','Home','End','Escape',' ','r','R'].includes(e.key)){
   e.preventDefault();e.stopImmediatePropagation();parent.postMessage({type:'deck-key',key:e.key},'*');
  }
 },true);
})();
