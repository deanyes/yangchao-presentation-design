# 内容自由，技术保持可靠

## 从空外壳开始

运行 `python3 "<技能目录>/scripts/new_deck.py" "<新输出目录>"`，或只复制 templates/starter/。脚本不覆盖已有路径；会附上来源与许可证，创建空 slides/ 与 assets/。starter 的 manifest 为空，显示“尚未添加演示页”是开发状态，不能当作成品。

先按设计制作单生成页面，再填 index.html 的 window.DECK_MANIFEST，例如：
`[{file:"slides/01-question.html",label:"这次分享的关键问题",steps:0}]`
label 是概览识别信息，不必成为页面眉题。页数与步骤应依据材料，不依文件名凑六页。

共享 theme.css 只给颜色、字体和画布基准，没有六页的固定结构。新页可用 grid/flex 定义自己的区域；复杂动画再用局部 absolute。不要把旧 v4.css 的场景选择器带入整份作品。

## 最小页面结构（不是必用构图）

```html
<!doctype html>
<html lang="zh-CN">
<meta charset="utf-8">
<title>本页的具体标题</title>
<link rel="stylesheet" href="../shared/theme.css">
<main class="slide">
  <!-- 在这里实现本页真实内容与构图；不要交付这段注释当成品。 -->
</main>
<script src="../shared/slide-runtime.js"></script>
<script src="../shared/keyboard.js"></script>
<script>makeDeckStepper({max:0});</script>
</html>
```

分步页使用 makeDeckStepper({max:2,render(step){...}})，它更新 .step-0/1/2 和 data-step，并同步外壳；manifest steps 填 2。步骤是信息事件，不是动画个数。自动入场页 max/steps 为 0；重播由外壳重载。CSS 避免非活动内容仍能被键盘聚焦/屏幕阅读器读作同时可见的答案。

互斥状态可用 data-show-steps="0" 或 data-show-steps="1 2" 标记；stepper 会同步 aria-hidden 与 inert。视觉的 opacity/visibility/transform 仍由该页 CSS 控制，辅助语义与视觉必须一致。

不要给全页加透明点击层去盖住链接、视频、报告。外壳有上/下一步按钮和键盘导航；如确需点击局部证据推进，绑定明确区域。状态更新需幂等，后退与重入不累积定时器。

长内容的滚动容器用 `tabindex="0" data-deck-interactive`；方向键、空格用于阅读，Esc/R 交给外壳。可以提供打开原文入口，但不让导航覆盖正文/滚动条。

## 依赖与运行

步骤状态与连续动画分开：makeDeckStepper 管理信息阶段；按需加载 shared/motion.js 编排阶段内部运动，见 motion-design.md。steps:0 只表示无需额外点击，不能据此判断页面没有动画；steps>0 也不能证明已有连续动效。页面默认终态应可读，不依赖动画成功才能看见内容。

- 本地相对路径；HTML 与资源整包移动。模板默认无需网络、构建工具或额外技能，不等于所有浏览器都允许自动化工具打开 file://。
- 在可用浏览器做实际演示检查。若工具限制 file://，遵循限制，可用允许的本地开发预览做明确标注的测试；不规避安全策略，不声称已双击离线验证。
- 大量页优先真正的静态缩略图，不用无限画廊复制几百个活动 iframe。外壳在缩略图缺失时保持网格。
- 内容进入/退出需要正确取消音视频或复杂循环；页面不自动翻走。动画失败或减弱动态时仍能阅读。
- 不承诺原生 .pptx 或打印导出保留动效。实际未测试的导出不能写成能力。

## 打包与验收

scripts/check_deck.py <输出目录> 递归检查相关文本/依赖、标准 manifest JSON 兼容数组、旧样张哈希等。推荐 manifest 使用 JSON 合法的双引号字段；脚本不执行任意 JS。动态生成清单无法解析时会要求人工核查，不猜测通过。

观众包只含 index.html、slides、shared、assets、CREDITS.md 与许可证。讲者稿、素材来源、_work 制作单单独交付/保存在工作目录，不能让备稿内容变成页面。若演示确实需要完整原文，可作为有意的阅读附件放入 assets，而非泄漏私用材料。
